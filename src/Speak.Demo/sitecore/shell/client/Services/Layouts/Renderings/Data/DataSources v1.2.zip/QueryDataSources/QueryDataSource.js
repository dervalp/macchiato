﻿require.config({
  paths: {
    scItemService: "/sitecore/shell/client/Services/Assets/lib/itemService"
  }
});

Sitecore.component(["scItemService"], {
  name: "QueryDataSource",
  initialize: function () {

    if (this.IsDeferred === "False") {
      this.IsDeferred = false;
    }

    if (this.IncludeStandardTemplateFields === "False") {
      this.IncludeStandardTemplateFields = false;
    }

    if (this.IsBusy === "False") {
      this.IsBusy = false;
    }

    this.Service = new ItemService({
      url: "/api/sc/item"
    });

    this.query = this.Service.query(this.Query);

    if (this.Database) {
      this.query.parameter("Database", this.Database);
    }

    if (this.Fields) {
      this.query.parameter("Fields", this.Fields);
    }

    if (this.IncludeStandardTemplateFields) {
      this.query.parameter("IncludeStandardTemplateFields", this.IncludeStandardTemplateFields);
    }

    if (this.Page) {
      this.query.page(this.Page);
    }

    if (this.PageSize) {
      this.query.take(this.PageSize);
    }


    if(!this.IsDeferred) {
      this.execute();
    }
  },
  initialized: function () {
    var query = this.query;

    this.on("change:Database", function (value) {
      query.parameter("Database", value);
    });

    this.on("change:Fields", function (value) {
      query.parameter("Fields", value);
    });

    this.on("change:IncludeStandardTemplateFields", function (value) {
      query.parameter("IncludeStandardTemplateFields", value);
    });

    this.on("change:Page", function (value) {
      query.page(value);
    });

    this.on("change:PageSize", function (value) {
      query.PageSize(value);
    });
  },
  execute: function () {
    var comp = this;

    this.IsBusy = true;

    return this.query.execute().then(function (items) {

      comp.TotalPage = items.TotalPage;
      comp.TotalCount = items.TotalPage;
      comp.Items = items.Results;

      this.IsBusy = false;
    });
  }
});
