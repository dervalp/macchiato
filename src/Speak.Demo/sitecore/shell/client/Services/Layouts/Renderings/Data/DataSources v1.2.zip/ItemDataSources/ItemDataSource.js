﻿require.config({
  paths: {
    scItemService: "/sitecore/shell/client/Services/Assets/lib/itemService"
  }
});

Sitecore.component(["scItemService"], {
  name: "ItemDataSource",
  initialize: function () {

    if (this.IsDeferred === "False") {
      this.IsDeferred = false;
    }

    if (this.IncludeStandardValues === "False") {
      this.IncludeStandardValues = false;
    }

    if (this.IsBusy === "False") {
      this.IsBusy = false;
    }

    if (this.IncludeMetaData === "False") {
      this.IncludeMetaData = false;
    }

    this.Service = new ItemService({
      url: "/api/sc/item"
    });

    this.query = this.Service.fetchItem(this.ItemId);

    if (this.Database) {
      this.query.parameter("Database", this.Database);
    }

    if (this.Language) {
      this.query.parameter("Language", this.Language);
    }

    if (this.Version) {
      this.query.parameter("Version", this.Version);
    }

    if (this.Fields) {
      this.query.parameter("Fields", this.Fields);
    }

    if (this.IncludeStandardValues) {
      this.query.parameter("IncludeStandardValues", this.IncludeStandardValues);
    }

    if (this.IncludeMetaData) {
      this.query.parameter("IncludeMetaData", this.IncludeMetaData);
    }

    /*if (this.IsReadOnly) {
      this.query.parameter("IsReadOnly", this.IsReadOnly);
    }*/

    if(!this.IsDeferred) {
      this.execute();
    }
  },
  initialized: function() {
    var query = this.query;

    this.on("change:Database", function (value) {
      query.parameter("Database", value);
    });

    this.on("change:Language", function (value) {
      query.parameter("Language", value);
    });

    this.on("change:Version", function (value) {
      query.parameter("Version", value);
    });

    this.on("change:Fields", function (value) {
      query.parameter("Fields", value);
    });

    this.on("change:IncludeStandardValues", function (value) {
      query.parameter("IncludeStandardValues", value);
    });

    this.on("change:IncludeMetaData", function (value) {
      query.parameter("IncludeMetaData", value);
    });
  },
  execute: function () {
    var comp = this;

    this.IsBusy = true;

    var loadChildren = function ( item ) {
      item.fetchChildren().execute().then(function (children) {
        var item = comp.Item;
        item.Children = children;
        comp.Item = item;
        this.IsBusy = false;
      });
    };

    if (this.IncludeChildren) {
      return this.query.execute().then(loadChildren);
    }

    return this.query.execute().then(function (item) {
      comp.set("Item", item);
      this.IsBusy = false;
    });
  }
});
